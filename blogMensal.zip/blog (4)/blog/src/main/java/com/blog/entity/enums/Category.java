package com.blog.entity.enums;

public enum Category {
    TECNOLOGIA,
    VIAGENS,
    CULINARIA,
    EDUCACAO,
    SAUDE,
    NEGOCIOS,
    ENTRETENIMENTO,
    ESPORTES,
    MODA,
    DESENVOLVIMENTO_PESSOAL

}
